# Description
In this project we would create an application that scrapes and aggregates announcements, postings, and emails from all around campus to find events that will be providing free food. It will compile these events in to one easy to use interface that can show students when and where to get the food and give them a registration link if needed.
# Opportunity
What do college students like more than free food? Anything? I would highly doubt it. Not only would this be a great way for hungry and poor college students to get some free grub for the night, but also it would allow organizations a chance to reach a new audience without any additional work. We could bring two groups together, those that want people and their events and those who are hungry.
# Used Techniques
* Followed MVC design pattern
* Built user interface with JavaFX
* Used Apache Derby DB as backend relational database
